<?php
    session_abort();
    header("location: login.php");
?>